package chap01.basic;

public class p01_introduce {
	public static void main(String[] args) {
		System.out.println("Java training");
	}
}
